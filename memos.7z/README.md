# Memos 
Software designed to automate repetition of data for more efficient memorization.


