
$(document).ready(function(){
    $("#keyboard2").on("keydown",function search(e) {
        if(e.keyCode == 13) {
       next()
        }
    });
    
})
 