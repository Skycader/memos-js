/*
let p2n4 = document.querySelector(".page2-node4");
p2n4.addEventListener("scroll", function(e){
    setTimeout(checkP2N4,500)
})

checkP2N4 = () => {
    if (p2n4.scrollTop < 360) {
        p2n4.scrollTo(0,360)
    }
}
*/